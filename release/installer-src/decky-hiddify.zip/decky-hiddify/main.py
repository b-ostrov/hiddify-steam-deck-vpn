import decky
import asyncio
import subprocess
import os
import json
import copy
import stat
import socket
import struct
import sqlite3
import datetime
import re
import ssl
import urllib.request
import urllib.error

# Decky PluginLoader is a PyInstaller bundle that sets LD_LIBRARY_PATH to its
# own extracted libs dir (/tmp/_MEI.../). This leaks into every subprocess and
# causes systemctl (and other system binaries) to load the wrong libcrypto.so.3,
# producing: "version `OPENSSL_3.4.0' not found". Clear it at import time.
os.environ.pop("LD_LIBRARY_PATH", None)

INSTALL_DIR  = "/opt/hiddify"
CLI_PATH     = f"{INSTALL_DIR}/HiddifyCli"
GUI_PATH     = f"{INSTALL_DIR}/hiddify"
APP_DIR      = "/home/deck/.local/share/app.hiddify.com"
CONFIG_PATH  = f"{APP_DIR}/data/current-config.json"
PROFILES_DB  = f"{APP_DIR}/db.sqlite"
CONFIGS_DIR  = f"{APP_DIR}/configs"
APP_LOG_PATH = f"{APP_DIR}/app.log"
DEBUG_LOG_PATH = f"{APP_DIR}/decky-debug.log"
HIDDIFY_SETTINGS_PATH = f"{APP_DIR}/data/decky-hiddify-settings.json"
SERVER_SELECTION_PATH = f"{APP_DIR}/decky-server-selection.json"
USER_SERVICE_PATH = "/home/deck/.config/systemd/user/hiddify.service"

GRPC_PORT = 17078  # GUI in-process gRPC port
CLASH_API_PORT = 16756  # sing-box Clash-compatible control API (hot reload)
SYSTEMD_START_TIMEOUT = 30
CORE_GENERATED_TAGS = {"auto", "balance", "lowest", "select"}
HIDDEN_OUTBOUND_TYPES = {"selector", "urltest", "balancer", "direct", "block", "dns"}
HIDDEN_OUTBOUND_TAGS = {
    "auto",
    "balance",
    "block",
    "bypass",
    "direct",
    "dns",
    "fragment",
    "lowest",
    "select",
    "warp",
}

PLUGIN_VERSION = "unknown"
try:
    with open(os.path.join(os.path.dirname(__file__), "plugin.json")) as f:
        PLUGIN_VERSION = str(json.load(f).get("version", "unknown"))
except Exception:
    pass


def _compact_process_result(result: subprocess.CompletedProcess) -> dict:
    return {
        "rc": result.returncode,
        "stdout": (result.stdout or "").strip()[-500:],
        "stderr": (result.stderr or "").strip()[-500:],
    }


def _scrub_sensitive(value):
    """Keep debug logs useful without leaking subscription URLs or tokens."""
    if isinstance(value, str):
        return re.sub(r"https?://[^\s\"']+", "<URL>", value)
    if isinstance(value, list):
        return [_scrub_sensitive(item) for item in value]
    if isinstance(value, dict):
        return {key: _scrub_sensitive(item) for key, item in value.items()}
    return value


class Plugin:
    _monitor_task = None
    _user_stopped  = False  # set True when user explicitly stops VPN via plugin

    # ── Minimal HTTP/2 gRPC helpers ────────────────────────────────────────────

    @staticmethod
    def _h2_frame(type_, flags, stream_id, payload=b''):
        return struct.pack('>I', len(payload))[1:] + bytes([type_, flags]) + struct.pack('>I', stream_id) + payload

    @staticmethod
    def _hpack_str(s):
        b = s.encode() if isinstance(s, str) else s
        return bytes([len(b)]) + b

    @staticmethod
    def _pb_string(field_num, value):
        """Encode a protobuf string field (wire type 2). Supports length up to 16383."""
        b = value.encode() if isinstance(value, str) else value
        tag = (field_num << 3) | 2
        n = len(b)
        if n < 128:
            length_bytes = bytes([n])
        else:
            length_bytes = bytes([(n & 0x7F) | 0x80, n >> 7])
        return bytes([tag]) + length_bytes + b

    def _grpc_call(self, method_path, request_body=b'', port=GRPC_PORT, timeout=5):
        """
        Send a single gRPC unary call using raw HTTP/2 sockets.
        Returns the gRPC response body bytes, or None on failure.
        """
        h2 = self._h2_frame
        hs = self._hpack_str
        authority = f'127.0.0.1:{port}'

        # HPACK encoded request headers
        hpack = (
            bytes([0x83])                          # :method: POST
            + bytes([0x86])                        # :scheme: http
            + bytes([0x44]) + hs(method_path)      # :path
            + bytes([0x41]) + hs(authority)        # :authority
            + bytes([0x40]) + hs('content-type') + hs('application/grpc')
            + bytes([0x40]) + hs('te')             + hs('trailers')
        )

        # gRPC message framing: 1 byte compressed flag + 4 byte length + body
        grpc_msg = b'\x00' + struct.pack('>I', len(request_body)) + request_body

        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(timeout)
            s.connect(('127.0.0.1', port))

            # Send HTTP/2 connection preface + our SETTINGS
            s.sendall(b'PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n' + h2(0x04, 0x00, 0))

            # Read server SETTINGS and ACK it
            raw = b''
            try:
                raw = s.recv(4096)
            except socket.timeout:
                pass
            i = 0
            while i + 9 <= len(raw):
                frame_len = struct.unpack('>I', b'\x00' + raw[i:i+3])[0]
                frame_type = raw[i+3]
                frame_flags = raw[i+4]
                if frame_type == 0x04 and not (frame_flags & 0x01):
                    s.sendall(h2(0x04, 0x01, 0))  # SETTINGS_ACK
                i += 9 + frame_len

            # Send our request
            s.sendall(h2(0x01, 0x04, 1, hpack) + h2(0x00, 0x01, 1, grpc_msg))

            # Read response frames
            resp_raw = b''
            try:
                while True:
                    chunk = s.recv(4096)
                    if not chunk:
                        break
                    resp_raw += chunk
            except socket.timeout:
                pass

            s.close()

            # Parse DATA frame from response
            i = 0
            while i + 9 <= len(resp_raw):
                frame_len = struct.unpack('>I', b'\x00' + resp_raw[i:i+3])[0]
                frame_type = resp_raw[i+3]
                payload = resp_raw[i+9:i+9+frame_len]
                if frame_type == 0x00 and len(payload) >= 5:  # DATA frame
                    grpc_len = struct.unpack('>I', payload[1:5])[0]
                    return payload[5:5+grpc_len]
                i += 9 + frame_len

            return b''

        except Exception as e:
            decky.logger.debug(f"_grpc_call({method_path}:{port}) error: {e}")
            return None

    def _is_grpc_up(self, port=GRPC_PORT) -> bool:
        """Check if the GUI's gRPC server is reachable."""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(1)
            s.connect(('127.0.0.1', port))
            s.close()
            return True
        except Exception:
            return False

    def _grpc_stop(self) -> bool:
        """Call Core.Stop() on the running gRPC server. Returns True if sent."""
        result = self._grpc_call('/hcore.Core/Stop', b'', GRPC_PORT)
        if result is not None:
            decky.logger.info(f"gRPC Stop sent, response: {result.hex() if result else 'empty'}")
            return True
        return False

    def _grpc_start(self) -> bool:
        """Call Core.Start() on the running gRPC server with current config."""
        # Build StartRequest protobuf: config_path (field 1) + config_name (field 7)
        request = self._pb_string(1, CONFIG_PATH) + self._pb_string(7, "current-config")
        result = self._grpc_call('/hcore.Core/Start', request, GRPC_PORT)
        if result is not None:
            decky.logger.info(f"gRPC Start sent, response: {result.hex() if result else 'empty'}")
            return True
        return False

    # ── Clash API hot reload ───────────────────────────────────────────────────
    # sing-box exposes a Clash-compatible control API on 127.0.0.1:16756
    # (enabled via decky-hiddify-settings.json: enable-clash-api / clash-api-port).
    # PUT /configs {path} hot-reloads the running box from a config file WITHOUT
    # tearing down tun0 — verified on a Steam Deck (sing-box 1.13.1): tun0 stays
    # UP across the reload. This lets us apply a freshly rebuilt config to an
    # active VPN session with zero drop, which gRPC Core.Start/Stop cannot do
    # (those recreate tun0). Used by refresh_profile(apply_now=True).

    def _clash_reload_config(self, config_path: str = CONFIG_PATH) -> dict:
        """Hot-reload the running sing-box from config_path via Clash API.

        Returns {success, http_code, tun_up_after, error}. The reload is
        in-process (no systemctl, no tun0 teardown); if it fails we leave the
        running session untouched and the caller can fall back to restart.
        """
        import urllib.request as _u
        import json as _j
        result = {"success": False, "http_code": None, "tun_up_after": self._is_tun_up(), "error": None}
        payload = _j.dumps({"path": config_path}).encode()
        req = _u.Request(
            f"http://127.0.0.1:{CLASH_API_PORT}/configs?force=true",
            data=payload,
            method="PUT",
            headers={"Content-Type": "application/json"},
        )
        try:
            with _u.urlopen(req, timeout=10) as resp:
                result["http_code"] = resp.getcode()
                # 204 No Content is the normal success response from sing-box
                result["success"] = resp.getcode() in (200, 204)
        except Exception as e:
            result["error"] = str(e)
            decky.logger.warning(f"Clash API PUT /configs failed: {e}")
        await_sleep = 0
        # brief settle — let the box re-init before we re-check tun0
        import time as _t
        _t.sleep(1)
        result["tun_up_after"] = self._is_tun_up()
        return result

    # ── Helpers ────────────────────────────────────────────────────────────────

    def _check_caps(self) -> bool:
        if not os.path.exists(CLI_PATH):
            return False
        r = subprocess.run(["getcap", CLI_PATH], capture_output=True, text=True)
        return "cap_net_admin" in r.stdout

    def _tun_exists(self) -> bool:
        try:
            r = subprocess.run(["ip", "link", "show", "tun0"], capture_output=True, text=True)
            return r.returncode == 0
        except Exception:
            return False

    def _is_tun_up(self) -> bool:
        try:
            r = subprocess.run(["ip", "-j", "addr", "show", "tun0"], capture_output=True, text=True)
            if r.returncode != 0:
                return False
            data = json.loads(r.stdout)
            if not data:
                return False
            tun = data[0]
            if tun.get("operstate") == "DOWN":
                return False
            return any(addr.get("local") for addr in tun.get("addr_info", []))
        except Exception:
            return False

    def _get_vpn_ip(self) -> str:
        try:
            r = subprocess.run(["ip", "-j", "addr", "show", "tun0"], capture_output=True, text=True)
            if r.returncode == 0:
                data = json.loads(r.stdout)
                if data and data[0].get("addr_info"):
                    return data[0]["addr_info"][0].get("local", "")
        except Exception:
            pass
        return ""

    def _process_running(self) -> bool:
        service = self._service_snapshot()
        return self._service_is_active(service) or self._is_grpc_up()

    @staticmethod
    def _run_capture(args: list[str]) -> subprocess.CompletedProcess:
        return subprocess.run(args, capture_output=True, text=True)

    def _sudo_run(self, args: list[str]) -> subprocess.CompletedProcess:
        return self._run_capture(["sudo", "-n"] + args)

    def _cleanup_tun(self) -> dict:
        result = {}

        revert = self._run_capture(["/usr/bin/resolvectl", "revert", "tun0"])
        result["resolvectl_revert"] = {
            "rc": revert.returncode,
            "stderr": (revert.stderr or "").strip()[-300:],
        }

        fuser = self._sudo_run(["/usr/bin/fuser", "-k", "17078/tcp"])
        result["fuser_kill_17078"] = {
            "rc": fuser.returncode,
            "stderr": (fuser.stderr or "").strip()[-300:],
        }

        delete = self._sudo_run(["/usr/bin/ip", "link", "delete", "tun0"])
        result["ip_link_delete_tun0"] = {
            "rc": delete.returncode,
            "stderr": (delete.stderr or "").strip()[-300:],
        }

        result["tun_up_after_cleanup"] = self._is_tun_up()
        return result

    def _grpc_port_snapshot(self) -> dict:
        ss = self._run_capture(["ss", "-ltnp"])
        port = f":{GRPC_PORT}"
        ss_text = "\n".join(
            line for line in ((ss.stdout or "") + "\n" + (ss.stderr or "")).splitlines()
            if port in line
        )
        fuser = self._run_capture(["/usr/bin/fuser", "-v", f"{GRPC_PORT}/tcp"])
        return {
            "grpc_up": self._is_grpc_up(),
            "ss": ss_text[-1200:],
            "fuser": _compact_process_result(fuser),
        }

    def _cleanup_grpc_port(self) -> dict:
        result = {
            "grpc_up_before": self._is_grpc_up(),
            "port_before": self._grpc_port_snapshot(),
        }
        fuser = self._sudo_run(["/usr/bin/fuser", "-k", f"{GRPC_PORT}/tcp"])
        result["fuser_kill"] = _compact_process_result(fuser)
        result["grpc_up_after"] = self._is_grpc_up()
        result["port_after"] = self._grpc_port_snapshot()
        return result

    def _list_desktop_hiddify_units(self) -> list[str]:
        units = []
        r = self._systemctl_user(["list-units", "--all", "--no-legend", "app-hiddify@*.service"])
        for line in (r.stdout or "").splitlines():
            parts = line.split()
            if not parts:
                continue
            unit = parts[1] if parts[0] == "●" and len(parts) > 1 else parts[0]
            if unit.startswith("app-hiddify@") and unit.endswith(".service"):
                units.append(unit)
        return units

    def _desktop_hiddify_snapshot(self) -> dict:
        units = []
        for unit in self._list_desktop_hiddify_units():
            active = self._systemctl_user(["is-active", unit])
            show = self._systemctl_user([
                "show",
                unit,
                "--property=ActiveState,SubState,Result,ExecMainStatus,ExecMainPID",
            ])
            show_map = {}
            for line in (show.stdout or "").splitlines():
                if "=" in line:
                    key, value = line.split("=", 1)
                    show_map[key] = value
            units.append({
                "unit": unit,
                "active": (active.stdout or active.stderr).strip(),
                "show": show_map,
            })
        pgrep = self._run_capture(["pgrep", "-a", "-x", "hiddify"])
        return {
            "units": units,
            "pgrep_hiddify": _compact_process_result(pgrep),
            "port": self._grpc_port_snapshot(),
        }

    async def _stop_desktop_hiddify_runtime(self) -> dict:
        result = {
            "before": self._desktop_hiddify_snapshot(),
            "stopped_units": [],
        }

        for unit in self._list_desktop_hiddify_units():
            stop = self._systemctl_user(["stop", unit])
            result["stopped_units"].append({
                "unit": unit,
                "stop": _compact_process_result(stop),
            })

        if result["stopped_units"]:
            await asyncio.sleep(1)
        result["after_unit_stop"] = self._desktop_hiddify_snapshot()

        if self._is_grpc_up() or result["after_unit_stop"]["pgrep_hiddify"]["rc"] == 0:
            term = self._run_capture(["pkill", "-TERM", "-x", "hiddify"])
            result["pkill_term_hiddify"] = _compact_process_result(term)
            await asyncio.sleep(1)

        if self._is_grpc_up():
            kill = self._run_capture(["pkill", "-KILL", "-x", "hiddify"])
            result["pkill_kill_hiddify"] = _compact_process_result(kill)
            await asyncio.sleep(1)

        if self._is_grpc_up():
            result["grpc_port_cleanup"] = self._cleanup_grpc_port()
            await asyncio.sleep(1)

        result["after"] = self._desktop_hiddify_snapshot()
        return result

    @staticmethod
    def _tail_file(path: str, max_lines: int = 40) -> str:
        try:
            with open(path) as f:
                return "".join(f.readlines()[-max_lines:]).strip()
        except Exception:
            return ""

    def _debug_event(self, event: str, **fields):
        try:
            os.makedirs(APP_DIR, exist_ok=True)
            if os.path.exists(DEBUG_LOG_PATH) and os.path.getsize(DEBUG_LOG_PATH) > 512 * 1024:
                rotated = f"{DEBUG_LOG_PATH}.1"
                try:
                    os.remove(rotated)
                except FileNotFoundError:
                    pass
                os.rename(DEBUG_LOG_PATH, rotated)

            payload = {
                "ts": datetime.datetime.now().isoformat(timespec="seconds"),
                "event": event,
                "plugin_version": PLUGIN_VERSION,
            }
            payload.update(_scrub_sensitive(fields))
            with open(DEBUG_LOG_PATH, "a") as f:
                f.write(json.dumps(payload, ensure_ascii=False, sort_keys=True, default=str) + "\n")
        except Exception as e:
            decky.logger.debug(f"debug log write failed: {e}")

    def _config_summary(self) -> dict:
        summary = {
            "config_exists": os.path.exists(CONFIG_PATH),
            "profiles_db_exists": os.path.exists(PROFILES_DB),
            "configs_dir_exists": os.path.isdir(CONFIGS_DIR),
        }
        if not os.path.exists(CONFIG_PATH):
            return summary
        try:
            with open(CONFIG_PATH) as f:
                data = json.load(f)
            summary.update(self._config_data_summary(data))
        except Exception as e:
            summary["config_error"] = str(e)
        return summary

    # ── TUN / caps ─────────────────────────────────────────────────────────────

    def _apply_caps(self):
        if os.path.exists(CLI_PATH):
            subprocess.run(
                ["setcap", "cap_net_admin,cap_net_bind_service,cap_net_raw=+eip", CLI_PATH],
                capture_output=True,
            )

    def _ensure_tun(self):
        subprocess.run(["modprobe", "tun"], capture_output=True)
        if not os.path.exists("/dev/net/tun"):
            os.makedirs("/dev/net", exist_ok=True)
            os.mknod("/dev/net/tun", 0o666 | stat.S_IFCHR, os.makedev(10, 200))
            os.chmod("/dev/net/tun", 0o666)

    def _disable_tun_ipv6(self):
        """Disable IPv6 on tun0.

        HiddifyCli's FakeDNS returns both A and AAAA (fc00::/18) records.
        The Shadowsocks proxy typically can't forward IPv6, so curl/apps try
        the IPv6 fake address first (Happy Eyeballs), wait for a full TCP
        timeout (~20s), then fall back to IPv4. Disabling IPv6 on tun0 makes
        the kernel reject IPv6 connections instantly (ENETUNREACH) → immediate
        fallback to IPv4, no delay.
        """
        subprocess.run(
            ["sysctl", "-w", "net.ipv6.conf.tun0.disable_ipv6=1"],
            capture_output=True,
        )
        decky.logger.info("IPv6 disabled on tun0 (proxy does not forward IPv6)")

    # ── Install state ──────────────────────────────────────────────────────────

    def _get_install_state(self) -> tuple[str, str]:
        if not os.path.exists(CLI_PATH):
            return "not_installed", "Hiddify is not installed"
        if not self._check_caps():
            return "needs_repair", "setcap missing — click Repair"
        return "ready", "Ready"

    # ── Profile helpers ────────────────────────────────────────────────────────

    def _profile_meta(self, profile_id: str) -> dict:
        result = {
            "exists": False,
            "id": profile_id,
            "name": "",
            "type": "",
            "active": False,
            "has_url": False,
            "last_update": "",
            "update_interval": None,
        }
        try:
            db = sqlite3.connect(PROFILES_DB)
            db.row_factory = sqlite3.Row
            row = db.execute(
                "SELECT id, type, active, name, url, last_update, update_interval "
                "FROM profile_entries WHERE id = ?",
                (profile_id,),
            ).fetchone()
            db.close()
            if not row:
                return result
            url = str(row["url"] or "")
            result.update({
                "exists": True,
                "id": row["id"],
                "type": row["type"],
                "active": bool(row["active"]),
                "name": row["name"],
                "has_url": bool(url.strip()),
                "last_update": row["last_update"],
                "update_interval": row["update_interval"],
            })
            return result
        except Exception as e:
            result["error"] = str(e)
            return result

    def _profile_url(self, profile_id: str) -> str:
        try:
            db = sqlite3.connect(PROFILES_DB)
            row = db.execute("SELECT url FROM profile_entries WHERE id = ?", (profile_id,)).fetchone()
            db.close()
            return str(row[0] or "").strip() if row else ""
        except Exception:
            return ""

    def _read_profiles(self) -> list:
        try:
            db = sqlite3.connect(PROFILES_DB)
            cols = {row[1] for row in db.execute("PRAGMA table_info(profile_entries)")}
            if "active" in cols:
                if "url" in cols:
                    rows = db.execute(
                        "SELECT id, name, active, url FROM profile_entries ORDER BY name"
                    ).fetchall()
                    result = [
                        {"id": r[0], "name": r[1], "active": bool(r[2]), "remote": bool(str(r[3] or "").strip())}
                        for r in rows
                    ]
                else:
                    rows = db.execute(
                        "SELECT id, name, active FROM profile_entries ORDER BY name"
                    ).fetchall()
                    result = [{"id": r[0], "name": r[1], "active": bool(r[2]), "remote": False} for r in rows]
            else:
                rows = db.execute(
                    "SELECT id, name FROM profile_entries ORDER BY name"
                ).fetchall()
                result = [{"id": r[0], "name": r[1], "active": False, "remote": False} for r in rows]
            db.close()
            return result
        except Exception as e:
            decky.logger.error(f"_read_profiles: {e}")
            return []

    def _get_active_profile(self) -> dict | None:
        for p in self._read_profiles():
            if p["active"]:
                return p
        profiles = self._read_profiles()
        return profiles[0] if profiles else None

    @staticmethod
    def _hiddify_runtime_settings() -> dict:
        """Settings used by the Decky/systemd path when HiddifyCli builds config."""
        return {
            "region": "ru",
            "balancer-strategy": "round-robin",
            "block-ads": False,
            "use-xray-core-when-possible": False,
            "execute-config-as-is": False,
            "log-level": "warn",
            "resolve-destination": False,
            "ipv6-mode": "ipv4_only",
            "remote-dns-address": "tcp://8.8.8.8",
            "remote-dns-domain-strategy": "",
            "direct-dns-address": "1.1.1.1",
            "direct-dns-domain-strategy": "",
            "mixed-port": 12334,
            "tproxy-port": 12335,
            "direct-port": 12337,
            "redirect-port": 12336,
            "tun-implementation": "gvisor",
            "mtu": 9000,
            "strict-route": True,
            "connection-test-url": "http://captive.apple.com/hotspot-detect.html",
            "url-test-interval": 600,
            "enable-clash-api": True,
            "clash-api-port": 16756,
            "enable-tun": True,
            "set-system-proxy": False,
            "bypass-lan": False,
            "allow-connection-from-lan": False,
            "enable-fake-dns": False,
            "independent-dns-cache": True,
            "rules": [],
            "tls-tricks": {
                "enable-fragment": False,
                "fragment-size": "10-30",
                "fragment-sleep": "2-8",
                "mixed-sni-case": False,
                "enable-padding": False,
                "padding-size": "1-1500",
            },
            "warp": {
                "enable": False,
                "mode": "warp_over_proxy",
                "wireguard-config": "",
                "license-key": "",
                "account-id": "",
                "access-token": "",
                "clean-ip": "auto",
                "clean-port": 0,
                "noise": "1-3",
                "noise-size": "10-30",
                "noise-delay": "10-30",
                "noise-mode": "m4",
            },
            "warp2": {
                "enable": False,
                "mode": "warp_over_proxy",
                "wireguard-config": "",
                "license-key": "",
                "account-id": "",
                "access-token": "",
                "clean-ip": "auto",
                "clean-port": 0,
                "noise": "1-3",
                "noise-size": "10-30",
                "noise-delay": "10-30",
                "noise-mode": "m4",
            },
        }

    def _write_hiddify_runtime_settings(self) -> dict:
        result = {
            "path": HIDDIFY_SETTINGS_PATH,
            "success": False,
            "balancer_strategy": "round-robin",
        }
        try:
            os.makedirs(os.path.dirname(HIDDIFY_SETTINGS_PATH), exist_ok=True)
            tmp_path = f"{HIDDIFY_SETTINGS_PATH}.tmp"
            with open(tmp_path, "w") as f:
                json.dump(self._hiddify_runtime_settings(), f, ensure_ascii=False, indent=2)
            os.replace(tmp_path, HIDDIFY_SETTINGS_PATH)
            try:
                os.chown(HIDDIFY_SETTINGS_PATH, 1000, 1000)
            except Exception:
                pass
            result["success"] = True
        except Exception as e:
            result["error"] = str(e)
            decky.logger.error(f"Failed to write Hiddify runtime settings: {e}")
        return result

    def _ensure_user_service(self) -> dict:
        result = {
            "path": USER_SERVICE_PATH,
            "success": False,
            "settings_path": HIDDIFY_SETTINGS_PATH,
        }
        service_text = f"""[Unit]
Description=Hiddify VPN Core Service
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory={APP_DIR}
Environment=HOME=/home/deck USER=deck
ExecStart={CLI_PATH} run -c {CONFIG_PATH} --tun -d {HIDDIFY_SETTINGS_PATH}
Restart=on-failure
RestartSec=5

[Install]
WantedBy=default.target
"""
        try:
            os.makedirs(os.path.dirname(USER_SERVICE_PATH), exist_ok=True)
            current = ""
            if os.path.exists(USER_SERVICE_PATH):
                with open(USER_SERVICE_PATH) as f:
                    current = f.read()
            result["changed"] = current != service_text
            if result["changed"]:
                tmp_path = f"{USER_SERVICE_PATH}.tmp"
                with open(tmp_path, "w") as f:
                    f.write(service_text)
                os.replace(tmp_path, USER_SERVICE_PATH)
                try:
                    os.chown(USER_SERVICE_PATH, 1000, 1000)
                except Exception:
                    pass
            self._systemctl_user(["daemon-reload"])
            result["autostart"] = self._disable_user_service_autostart()
            result["success"] = True
        except Exception as e:
            result["error"] = str(e)
            decky.logger.warning(f"Could not ensure hiddify user service: {e}")
        return result

    @staticmethod
    def _display_server_name(tag: str) -> str:
        return (
            str(tag or "")
            .replace("§default§", "")
            .replace("§hide§", "")
            .strip()
            or "Unnamed server"
        )

    @staticmethod
    def _is_hidden_outbound(outbound: dict) -> bool:
        tag = str(outbound.get("tag") or "")
        outbound_type = str(outbound.get("type") or "").lower()
        if not tag or "§hide§" in tag:
            return True
        return tag in HIDDEN_OUTBOUND_TAGS or outbound_type in HIDDEN_OUTBOUND_TYPES

    def _selectable_servers_from_config(self, config: dict) -> list:
        servers = []
        seen_tags = set()
        for outbound in config.get("outbounds", []):
            if not isinstance(outbound, dict) or self._is_hidden_outbound(outbound):
                continue
            tag = outbound.get("tag")
            if not tag or tag in seen_tags:
                continue
            seen_tags.add(tag)
            servers.append({
                "tag": tag,
                "name": self._display_server_name(tag),
                "type": str(outbound.get("type") or "unknown"),
                "server": str(outbound.get("server") or outbound.get("address") or ""),
                "port": str(outbound.get("server_port") or outbound.get("port") or ""),
            })
        return servers

    def _read_server_selection_state(self) -> dict:
        try:
            with open(SERVER_SELECTION_PATH) as f:
                data = json.load(f)
            return data if isinstance(data, dict) else {}
        except FileNotFoundError:
            return {}
        except Exception as e:
            decky.logger.warning(f"Failed to read server selection state: {e}")
            return {}

    def _write_server_selection_state(self, state: dict) -> dict:
        result = {"path": SERVER_SELECTION_PATH, "success": False}
        try:
            os.makedirs(os.path.dirname(SERVER_SELECTION_PATH), exist_ok=True)
            tmp_path = f"{SERVER_SELECTION_PATH}.tmp"
            with open(tmp_path, "w") as f:
                json.dump(state, f, ensure_ascii=False, indent=2, sort_keys=True)
            os.replace(tmp_path, SERVER_SELECTION_PATH)
            try:
                os.chown(SERVER_SELECTION_PATH, 1000, 1000)
            except Exception:
                pass
            result["success"] = True
        except Exception as e:
            result["error"] = str(e)
        return result

    def _selected_server_state(self, profile_id: str, servers: list) -> dict:
        selectable = len(servers) > 1
        if not selectable:
            return {
                "mode": "single",
                "tag": servers[0]["tag"] if servers else "",
                "name": servers[0]["name"] if servers else "",
                "valid": True,
            }

        state = self._read_server_selection_state().get(profile_id, {})
        tags = {server["tag"] for server in servers}
        if state.get("mode") == "manual" and state.get("tag") in tags:
            tag = state["tag"]
            server = next((item for item in servers if item["tag"] == tag), None)
            return {
                "mode": "manual",
                "tag": tag,
                "name": server["name"] if server else self._display_server_name(tag),
                "valid": True,
            }

        return {
            "mode": "auto",
            "tag": "",
            "name": "Hiddify default",
            "valid": True,
            "fallback_reason": "missing-or-invalid-saved-selection" if state else "",
        }

    def _normalized_profile_config(self, profile_id: str) -> dict:
        result = {
            "success": False,
            "profile_id": profile_id,
            "profile_config_path": os.path.join(CONFIGS_DIR, f"{profile_id}.json"),
        }
        if not os.path.exists(result["profile_config_path"]):
            result["error"] = f"Profile config not found: {result['profile_config_path']}"
            return result
        try:
            with open(result["profile_config_path"]) as f:
                profile_data = json.load(f)
            service_config = copy.deepcopy(profile_data)
            result["profile_summary"] = self._config_data_summary(profile_data)
            result["reserved_profile_tag_normalization"] = self._normalize_reserved_profile_tags(service_config)
            result["service_tag_normalization"] = self._normalize_tag_collisions(service_config)
            result["service_config"] = service_config
            result["service_input_summary"] = self._config_data_summary(service_config)
            result["success"] = True
        except Exception as e:
            result["error"] = str(e)
        return result

    def _profile_server_info_from_config(self, profile_id: str, config: dict) -> dict:
        servers = self._selectable_servers_from_config(config)
        selected = self._selected_server_state(profile_id, servers)
        return {
            "profile_id": profile_id,
            "selectable": len(servers) > 1,
            "servers": servers,
            "selected": selected,
            "count": len(servers),
        }

    def _profile_server_info(self, profile_id: str) -> dict:
        normalized = self._normalized_profile_config(profile_id)
        if not normalized.get("success"):
            return {
                "profile_id": profile_id,
                "selectable": False,
                "servers": [],
                "selected": {"mode": "none", "tag": "", "name": "", "valid": False},
                "count": 0,
                "error": normalized.get("error", "Failed to read profile config"),
            }
        info = self._profile_server_info_from_config(profile_id, normalized["service_config"])
        info["profile_summary"] = normalized.get("profile_summary", {})
        info["service_input_summary"] = normalized.get("service_input_summary", {})
        info["remote"] = self._profile_meta(profile_id).get("has_url", False)
        return info

    def _reset_invalid_server_selection(self, profile_id: str, info: dict) -> dict:
        selected = info.get("selected") or {}
        result = {"changed": False, "reason": ""}
        if selected.get("mode") != "auto" or not selected.get("fallback_reason"):
            return result

        state = self._read_server_selection_state()
        if profile_id in state:
            state[profile_id] = {"mode": "auto", "tag": ""}
            write = self._write_server_selection_state(state)
            result.update({
                "changed": write.get("success", False),
                "reason": selected.get("fallback_reason", ""),
                "write": write,
            })
        return result

    @staticmethod
    def _referenced_outbound_tags(outbound: dict) -> set[str]:
        refs = set()
        for key in ("detour", "download_detour", "upload_detour", "outbound"):
            value = outbound.get(key)
            if isinstance(value, str) and value:
                refs.add(value)
        return refs

    def _filter_config_to_selected_server(self, config: dict, selected_tag: str) -> dict:
        result = {
            "mode": "manual",
            "selected_tag": selected_tag,
            "success": False,
            "kept_tags": [],
        }
        outbounds = config.get("outbounds", [])
        if not isinstance(outbounds, list):
            result["error"] = "outbounds is not a list"
            return result

        by_tag = {
            outbound.get("tag"): outbound
            for outbound in outbounds
            if isinstance(outbound, dict) and outbound.get("tag")
        }
        if selected_tag not in by_tag:
            result["error"] = f"Selected server is not present in profile: {selected_tag}"
            return result

        keep = set()
        queue = [selected_tag]
        while queue:
            tag = queue.pop(0)
            if tag in keep:
                continue
            outbound = by_tag.get(tag)
            if not outbound:
                continue
            keep.add(tag)
            for ref in self._referenced_outbound_tags(outbound):
                if ref in by_tag and ref not in keep:
                    queue.append(ref)

        config["outbounds"] = [
            outbound
            for outbound in outbounds
            if isinstance(outbound, dict) and outbound.get("tag") in keep
        ]
        result["kept_tags"] = [outbound.get("tag") for outbound in config["outbounds"]]
        result["success"] = True
        return result

    def _apply_server_selection(self, profile_id: str, config: dict) -> dict:
        info = self._profile_server_info_from_config(profile_id, config)
        result = {
            "profile_id": profile_id,
            "selectable": info["selectable"],
            "server_count": info["count"],
            "selected": info["selected"],
            "action": "none",
            "success": True,
        }
        if not info["selectable"]:
            result["action"] = "single-server-profile"
            return result

        selected = info["selected"]
        if selected.get("mode") != "manual":
            result["action"] = "hiddify-default"
            return result

        filtered = self._filter_config_to_selected_server(config, selected.get("tag", ""))
        result["action"] = "manual-server-filter"
        result["filter"] = filtered
        result["success"] = filtered.get("success", False)
        if not result["success"]:
            result["error"] = filtered.get("error", "Failed to apply selected server")
        return result

    @staticmethod
    def _unique_tag(base: str, used_tags: set[str]) -> str:
        candidate = base
        index = 2
        while candidate in used_tags:
            candidate = f"{base}-{index}"
            index += 1
        used_tags.add(candidate)
        return candidate

    @staticmethod
    def _duplicate_tags(tags: list[str]) -> list[str]:
        counts = {}
        for tag in tags:
            counts[tag] = counts.get(tag, 0) + 1
        return sorted(tag for tag, count in counts.items() if count > 1)

    def _config_data_summary(self, data: dict) -> dict:
        outbound_tags_list = [
            item.get("tag")
            for item in data.get("outbounds", [])
            if isinstance(item, dict) and item.get("tag")
        ]
        endpoint_tags_list = [
            item.get("tag")
            for item in data.get("endpoints", [])
            if isinstance(item, dict) and item.get("tag")
        ]
        outbound_tags = set(outbound_tags_list)
        endpoint_tags = set(endpoint_tags_list)
        return {
            "outbounds_count": len(data.get("outbounds", [])),
            "endpoints_count": len(data.get("endpoints", [])),
            "duplicate_outbound_tags": self._duplicate_tags(outbound_tags_list),
            "duplicate_endpoint_tags": self._duplicate_tags(endpoint_tags_list),
            "duplicate_outbound_endpoint_tags": sorted(outbound_tags & endpoint_tags),
            "reserved_outbound_tags": sorted(outbound_tags & CORE_GENERATED_TAGS),
            "reserved_endpoint_tags": sorted(endpoint_tags & CORE_GENERATED_TAGS),
            "has_dns": "dns" in data,
            "has_route": "route" in data,
            "top_level_keys": sorted(data.keys()),
            "tun_inbounds": [
                inbound.get("type")
                for inbound in data.get("inbounds", [])
                if isinstance(inbound, dict) and inbound.get("type") == "tun"
            ],
        }

    def _rewrite_profile_tag_references(self, config: dict, rename_map: dict[str, str]) -> int:
        """Rewrite common sing-box tag reference fields after profile tag renames."""
        if not rename_map:
            return 0

        rewritten = 0
        list_reference_keys = {"outbounds"}
        string_reference_keys = {
            "default",
            "detour",
            "download_detour",
            "final",
            "interrupt_exist_connections",
            "outbound",
            "upload_detour",
        }

        def walk(node):
            nonlocal rewritten
            if isinstance(node, dict):
                for key, value in list(node.items()):
                    if key in list_reference_keys and isinstance(value, list):
                        new_values = []
                        changed = False
                        for item in value:
                            if isinstance(item, str) and item in rename_map:
                                new_values.append(rename_map[item])
                                rewritten += 1
                                changed = True
                            else:
                                new_values.append(item)
                        if changed:
                            node[key] = new_values
                        for item in new_values:
                            walk(item)
                    elif key in string_reference_keys and isinstance(value, str) and value in rename_map:
                        node[key] = rename_map[value]
                        rewritten += 1
                    else:
                        walk(value)
            elif isinstance(node, list):
                for item in node:
                    walk(item)

        walk(config)
        return rewritten

    def _normalize_reserved_profile_tags(self, config: dict) -> dict:
        """Rename profile tags that HiddifyCli generates again during `run --tun`."""
        result = {
            "renamed": [],
            "renamed_outbounds": [],
            "renamed_endpoints": [],
            "reference_rewrites": 0,
            "reserved_outbound_tags_before": [],
            "reserved_outbound_tags_after": [],
            "reserved_endpoint_tags_before": [],
            "reserved_endpoint_tags_after": [],
        }
        outbounds = config.get("outbounds", [])
        endpoints = config.get("endpoints", [])
        if not isinstance(outbounds, list) or not isinstance(endpoints, list):
            return result

        outbound_tags = [
            item.get("tag")
            for item in outbounds
            if isinstance(item, dict) and item.get("tag")
        ]
        endpoint_tags = [
            item.get("tag")
            for item in endpoints
            if isinstance(item, dict) and item.get("tag")
        ]
        result["reserved_outbound_tags_before"] = sorted(set(outbound_tags) & CORE_GENERATED_TAGS)
        result["reserved_endpoint_tags_before"] = sorted(set(endpoint_tags) & CORE_GENERATED_TAGS)

        used_tags = set(outbound_tags) | set(endpoint_tags)
        rename_map = {}

        for outbound in outbounds:
            if not isinstance(outbound, dict):
                continue
            old_tag = outbound.get("tag")
            if old_tag not in CORE_GENERATED_TAGS:
                continue
            new_tag = self._unique_tag(f"{old_tag}-outbound", used_tags)
            outbound["tag"] = new_tag
            rename_map.setdefault(old_tag, new_tag)
            entry = {"kind": "outbound", "old": old_tag, "new": new_tag, "reason": "reserved-core-tag"}
            result["renamed"].append(entry)
            result["renamed_outbounds"].append(entry)

        for endpoint in endpoints:
            if not isinstance(endpoint, dict):
                continue
            old_tag = endpoint.get("tag")
            if old_tag not in CORE_GENERATED_TAGS:
                continue
            new_tag = self._unique_tag(f"{old_tag}-endpoint", used_tags)
            endpoint["tag"] = new_tag
            rename_map.setdefault(old_tag, new_tag)
            entry = {"kind": "endpoint", "old": old_tag, "new": new_tag, "reason": "reserved-core-tag"}
            result["renamed"].append(entry)
            result["renamed_endpoints"].append(entry)

        result["reference_rewrites"] = self._rewrite_profile_tag_references(config, rename_map)

        new_outbound_tags = {
            item.get("tag")
            for item in outbounds
            if isinstance(item, dict) and item.get("tag")
        }
        new_endpoint_tags = {
            item.get("tag")
            for item in endpoints
            if isinstance(item, dict) and item.get("tag")
        }
        result["reserved_outbound_tags_after"] = sorted(new_outbound_tags & CORE_GENERATED_TAGS)
        result["reserved_endpoint_tags_after"] = sorted(new_endpoint_tags & CORE_GENERATED_TAGS)
        return result

    def _normalize_tag_collisions(self, config: dict) -> dict:
        """Fix HiddifyCli build output where generated tags collide with profile tags."""
        result = {
            "renamed": [],
            "renamed_outbounds": [],
            "renamed_endpoints": [],
            "reference_rewrites": 0,
            "duplicate_tags_before": [],
            "duplicate_tags_after": [],
            "duplicate_outbound_tags_before": [],
            "duplicate_outbound_tags_after": [],
            "duplicate_endpoint_tags_before": [],
            "duplicate_endpoint_tags_after": [],
        }
        outbounds = config.get("outbounds", [])
        endpoints = config.get("endpoints", [])
        if not isinstance(outbounds, list) or not isinstance(endpoints, list):
            return result

        outbound_tag_list = [
            item.get("tag")
            for item in outbounds
            if isinstance(item, dict) and item.get("tag")
        ]
        endpoint_tag_list = [
            item.get("tag")
            for item in endpoints
            if isinstance(item, dict) and item.get("tag")
        ]
        result["duplicate_outbound_tags_before"] = self._duplicate_tags(outbound_tag_list)
        result["duplicate_endpoint_tags_before"] = self._duplicate_tags(endpoint_tag_list)
        result["duplicate_tags_before"] = sorted(set(outbound_tag_list) & set(endpoint_tag_list))

        used_tags = set(outbound_tag_list) | set(endpoint_tag_list)
        rename_map = {}

        seen_outbound_tags = set()
        for outbound in outbounds:
            if not isinstance(outbound, dict):
                continue
            old_tag = outbound.get("tag")
            if not old_tag:
                continue
            if old_tag in seen_outbound_tags:
                new_tag = self._unique_tag(f"{old_tag}-outbound", used_tags)
                outbound["tag"] = new_tag
                rename_map.setdefault(old_tag, new_tag)
                entry = {"kind": "outbound", "old": old_tag, "new": new_tag}
                result["renamed"].append(entry)
                result["renamed_outbounds"].append(entry)
            else:
                seen_outbound_tags.add(old_tag)

        outbound_tags_after = {
            item.get("tag")
            for item in outbounds
            if isinstance(item, dict) and item.get("tag")
        }

        seen_endpoint_tags = set()
        for endpoint in endpoints:
            if not isinstance(endpoint, dict):
                continue
            old_tag = endpoint.get("tag")
            if not old_tag:
                continue
            if old_tag in outbound_tags_after or old_tag in seen_endpoint_tags:
                new_tag = self._unique_tag(f"{old_tag}-endpoint", used_tags)
                endpoint["tag"] = new_tag
                rename_map.setdefault(old_tag, new_tag)
                entry = {"kind": "endpoint", "old": old_tag, "new": new_tag}
                result["renamed"].append(entry)
                result["renamed_endpoints"].append(entry)
            else:
                seen_endpoint_tags.add(old_tag)

        if not rename_map:
            result["duplicate_outbound_tags_after"] = self._duplicate_tags(outbound_tag_list)
            result["duplicate_endpoint_tags_after"] = self._duplicate_tags(endpoint_tag_list)
            return result

        generated_group_tags = CORE_GENERATED_TAGS

        def rewrite_outbound_list(values, parent_tag):
            if not isinstance(values, list):
                return values
            rewritten = list(values)
            for old_tag, new_tag in rename_map.items():
                occurrences = [i for i, value in enumerate(rewritten) if value == old_tag]
                if not occurrences:
                    continue
                if parent_tag == old_tag or parent_tag in generated_group_tags or old_tag not in outbound_tags_after:
                    indexes_to_rewrite = occurrences
                elif len(occurrences) > 1:
                    indexes_to_rewrite = occurrences[1:]
                else:
                    indexes_to_rewrite = []
                for index in indexes_to_rewrite:
                    rewritten[index] = new_tag
                    result["reference_rewrites"] += 1
            return rewritten

        def walk(node, parent_tag=None):
            if isinstance(node, dict):
                current_tag = node.get("tag", parent_tag)
                for key, value in list(node.items()):
                    if key == "outbounds" and isinstance(value, list) and all(isinstance(item, str) for item in value):
                        node[key] = rewrite_outbound_list(value, current_tag)
                    else:
                        walk(value, current_tag)
            elif isinstance(node, list):
                for item in node:
                    walk(item, parent_tag)

        walk(config)

        new_endpoint_tags = {
            item.get("tag")
            for item in endpoints
            if isinstance(item, dict) and item.get("tag")
        }
        new_outbound_tag_list = [
            item.get("tag")
            for item in outbounds
            if isinstance(item, dict) and item.get("tag")
        ]
        new_endpoint_tag_list = [
            item.get("tag")
            for item in endpoints
            if isinstance(item, dict) and item.get("tag")
        ]
        result["duplicate_outbound_tags_after"] = self._duplicate_tags(new_outbound_tag_list)
        result["duplicate_endpoint_tags_after"] = self._duplicate_tags(new_endpoint_tag_list)
        result["duplicate_tags_after"] = sorted(set(new_outbound_tag_list) & new_endpoint_tags)
        return result

    def _rebuild_config(self, profile_id: str) -> dict:
        """Regenerate current-config.json from the selected profile via HiddifyCli."""
        result = {
            "success": False,
            "method": "hiddifycli.build",
            "profile_id": profile_id,
        }
        profile_config_path = os.path.join(CONFIGS_DIR, f"{profile_id}.json")
        result["profile_config_path"] = profile_config_path

        if not os.path.exists(profile_config_path):
            error = f"Profile config not found: {profile_config_path}"
            decky.logger.error(error)
            result["error"] = error
            return result

        temp_output_path = f"{CONFIG_PATH}.rebuilt.tmp"
        result["temp_output_path"] = temp_output_path
        settings_result = self._write_hiddify_runtime_settings()
        result["hiddify_settings"] = settings_result
        if not settings_result.get("success"):
            error = f"Failed to write Hiddify settings: {settings_result.get('error', 'unknown error')}"
            decky.logger.error(error)
            result["error"] = error
            return result

        normalized = self._normalized_profile_config(profile_id)
        if not normalized.get("success"):
            error = f"Failed to prepare profile config: {normalized.get('error', 'unknown error')}"
            decky.logger.error(error)
            result["error"] = error
            result["normalized"] = normalized
            return result

        service_config = normalized["service_config"]
        result["profile_summary"] = normalized.get("profile_summary", {})
        result["reserved_profile_tag_normalization"] = normalized.get("reserved_profile_tag_normalization", {})
        result["service_tag_normalization"] = normalized.get("service_tag_normalization", {})

        selection_result = self._apply_server_selection(profile_id, service_config)
        result["server_selection"] = selection_result
        if not selection_result.get("success", False):
            error = selection_result.get("error", "Failed to apply selected server")
            decky.logger.error(error)
            result["error"] = error
            return result

        result["service_input_summary"] = self._config_data_summary(service_config)

        service_input_problems = {
            "reserved_outbound": result["service_input_summary"].get("reserved_outbound_tags", []),
            "reserved_endpoint": result["service_input_summary"].get("reserved_endpoint_tags", []),
            "duplicate_outbound": result["service_input_summary"].get("duplicate_outbound_tags", []),
            "duplicate_endpoint": result["service_input_summary"].get("duplicate_endpoint_tags", []),
            "duplicate_outbound_endpoint": result["service_input_summary"].get("duplicate_outbound_endpoint_tags", []),
        }
        if any(service_input_problems.values()):
            error = f"Service input config still has unsafe tags: {service_input_problems}"
            decky.logger.error(error)
            result["error"] = error
            return result

        sanitized_input_path = f"{CONFIG_PATH}.service-input.tmp"
        result["sanitized_input_path"] = sanitized_input_path
        try:
            with open(sanitized_input_path, "w") as f:
                json.dump(service_config, f, ensure_ascii=False, indent=2)
        except Exception as e:
            error = f"Failed to write service input config: {e}"
            decky.logger.error(error)
            result["error"] = error
            return result

        try:
            os.remove(temp_output_path)
        except FileNotFoundError:
            pass

        cmd = [
            CLI_PATH,
            "build",
            "-c", sanitized_input_path,
            "--tun",
            "-d", HIDDIFY_SETTINGS_PATH,
            "--full-config",
            "-o", temp_output_path,
        ]
        result["command"] = cmd
        build = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            cwd=APP_DIR,
        )
        result["returncode"] = build.returncode
        result["stdout_tail"] = (build.stdout or "").strip()[-800:]
        result["stderr_tail"] = (build.stderr or "").strip()[-800:]
        if build.returncode != 0:
            error = f"HiddifyCli build failed with rc={build.returncode}"
            decky.logger.error(f"{error}: {(build.stderr or build.stdout).strip()[-400:]}")
            result["error"] = error
            return result

        if not os.path.exists(temp_output_path):
            error = f"Built config missing: {temp_output_path}"
            decky.logger.error(error)
            result["error"] = error
            return result

        try:
            with open(temp_output_path) as f:
                rebuilt = json.load(f)
        except Exception as e:
            error = f"Failed to parse built config: {e}"
            decky.logger.error(error)
            result["error"] = error
            return result

        if not rebuilt.get("outbounds"):
            error = "Built config has no outbounds"
            decky.logger.error(error)
            result["error"] = error
            return result

        tag_normalization = self._normalize_tag_collisions(rebuilt)
        result["validation_tag_normalization"] = tag_normalization
        duplicate_tags_after = {
            "outbound": tag_normalization.get("duplicate_outbound_tags_after", []),
            "endpoint": tag_normalization.get("duplicate_endpoint_tags_after", []),
            "outbound_endpoint": tag_normalization.get("duplicate_tags_after", []),
        }
        if any(duplicate_tags_after.values()):
            error = f"Built config still has duplicate tags: {duplicate_tags_after}"
            decky.logger.error(error)
            result["error"] = error
            return result

        result["rebuilt_summary"] = self._config_data_summary(rebuilt)
        result["write_mode"] = "sanitized_profile_for_hiddifycli_run"

        os.replace(sanitized_input_path, CONFIG_PATH)
        try:
            os.remove(temp_output_path)
        except FileNotFoundError:
            pass
        result["success"] = True
        return result

    # SteamOS system CA bundles. Decky's bundled Python often resolves its own
    # OpenSSL verify paths to a location without the CA store, so HTTPS
    # subscription downloads fail with CERTIFICATE_VERIFY_FAILED. Point the SSL
    # context at the system bundle explicitly.
    _CA_BUNDLES = (
        "/etc/ssl/certs/ca-certificates.crt",
        "/etc/ssl/cert.pem",
        "/etc/pki/tls/certs/ca-bundle.crt",
        "/etc/ca-certificates/extracted/tls-ca-bundle.pem",
    )

    def _ssl_context_for_download(self):
        ctx = ssl.create_default_context()
        for ca in self._CA_BUNDLES:
            if os.path.exists(ca):
                try:
                    ctx.load_verify_locations(cafile=ca)
                    return ctx
                except Exception:
                    continue
        return ctx

    def _download_subscription(self, url: str, dest_path: str) -> dict:
        """Download an HTTPS subscription to dest_path. Verifies TLS against the
        SteamOS CA bundle; on a CA-verification failure only, retries once with
        verification disabled so odd/self-signed endpoints still work (the
        downloaded payload is validated by HiddifyCli parse afterwards)."""
        request = urllib.request.Request(url, headers={"User-Agent": "hiddify-steam-deck/1.3.18"})
        info = {"tls_verified": True}
        try:
            with urllib.request.urlopen(request, timeout=30, context=self._ssl_context_for_download()) as response:
                data = response.read()
        except urllib.error.URLError as e:
            if not isinstance(getattr(e, "reason", None), ssl.SSLError):
                raise
            insecure = ssl.create_default_context()
            insecure.check_hostname = False
            insecure.verify_mode = ssl.CERT_NONE
            with urllib.request.urlopen(request, timeout=30, context=insecure) as response:
                data = response.read()
            info["tls_verified"] = False
        if not data:
            info["error"] = "Subscription response is empty"
            return info
        with open(dest_path, "wb") as f:
            f.write(data)
        try:
            os.chown(dest_path, 1000, 1000)
        except Exception:
            pass
        info["bytes"] = len(data)
        return info

    def _parse_remote_profile(self, profile_id: str, url: str) -> dict:
        profile_config_path = os.path.join(CONFIGS_DIR, f"{profile_id}.json")
        temp_profile_path = f"{profile_config_path}.refresh.tmp"
        temp_subscription_path = f"{profile_config_path}.subscription.tmp"
        result = {
            "success": False,
            "method": "hiddifycli.parse",
            "profile_id": profile_id,
            "profile_config_path": profile_config_path,
            "temp_profile_path": temp_profile_path,
            "temp_subscription_path": temp_subscription_path,
            "has_url": bool(url),
            "downloaded": False,
        }
        if not url:
            result["error"] = "Profile has no subscription URL"
            return result

        os.makedirs(CONFIGS_DIR, exist_ok=True)
        for path in (temp_profile_path, temp_subscription_path):
            try:
                os.remove(path)
            except FileNotFoundError:
                pass

        source_path = url
        if re.match(r"^https?://", url, re.IGNORECASE):
            try:
                download = self._download_subscription(url, temp_subscription_path)
                if download.get("error"):
                    result["error"] = download["error"]
                    return result
                source_path = temp_subscription_path
                result["downloaded"] = True
                result["subscription_bytes"] = download.get("bytes", 0)
                result["tls_verified"] = download.get("tls_verified", True)
            except Exception as e:
                result["error"] = f"Failed to download subscription: {e}"
                return result

        cmd = [CLI_PATH, "parse", source_path, "-o", temp_profile_path]
        result["command"] = [CLI_PATH, "parse", "<SUBSCRIPTION>", "-o", temp_profile_path]
        try:
            parsed = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                cwd=APP_DIR,
                timeout=60,
            )
        except subprocess.TimeoutExpired as e:
            result["error"] = "Subscription update timed out"
            result["stdout_tail"] = (e.stdout or "").strip()[-800:] if isinstance(e.stdout, str) else ""
            result["stderr_tail"] = (e.stderr or "").strip()[-800:] if isinstance(e.stderr, str) else ""
            try:
                os.remove(temp_subscription_path)
            except FileNotFoundError:
                pass
            return result
        except Exception as e:
            result["error"] = str(e)
            try:
                os.remove(temp_subscription_path)
            except FileNotFoundError:
                pass
            return result

        result["returncode"] = parsed.returncode
        result["stdout_tail"] = (parsed.stdout or "").strip()[-800:]
        result["stderr_tail"] = (parsed.stderr or "").strip()[-800:]
        if parsed.returncode != 0:
            result["error"] = f"HiddifyCli parse failed with rc={parsed.returncode}"
            try:
                os.remove(temp_subscription_path)
            except FileNotFoundError:
                pass
            return result
        if not os.path.exists(temp_profile_path):
            result["error"] = "Parsed profile config missing"
            try:
                os.remove(temp_subscription_path)
            except FileNotFoundError:
                pass
            return result

        try:
            with open(temp_profile_path) as f:
                parsed_config = json.load(f)
        except Exception as e:
            result["error"] = f"Failed to parse refreshed config: {e}"
            try:
                os.remove(temp_subscription_path)
            except FileNotFoundError:
                pass
            return result

        summary = self._config_data_summary(parsed_config)
        result["profile_summary"] = summary
        if not parsed_config.get("outbounds"):
            result["error"] = "Refreshed profile has no outbounds"
            try:
                os.remove(temp_subscription_path)
            except FileNotFoundError:
                pass
            return result

        try:
            os.replace(temp_profile_path, profile_config_path)
            try:
                os.remove(temp_subscription_path)
            except FileNotFoundError:
                pass
            try:
                os.chown(profile_config_path, 1000, 1000)
            except Exception:
                pass
        except Exception as e:
            result["error"] = f"Failed to save refreshed profile: {e}"
            try:
                os.remove(temp_subscription_path)
            except FileNotFoundError:
                pass
            return result

        result["success"] = True
        return result

    def _update_profile_last_update(self, profile_id: str) -> dict:
        result = {"success": False, "profile_id": profile_id}
        try:
            now = datetime.datetime.now().astimezone().isoformat(timespec="microseconds")
            db = sqlite3.connect(PROFILES_DB)
            db.execute("UPDATE profile_entries SET last_update = ? WHERE id = ?", (now, profile_id))
            db.commit()
            db.close()
            result.update({"success": True, "last_update": now})
        except Exception as e:
            result["error"] = str(e)
        return result

    def _sync_active_profile_config(self) -> dict:
        active = self._get_active_profile()
        result = {
            "active_profile": active["name"] if active else "",
            "active_profile_id": active["id"] if active else "",
            "attempted": False,
            "success": False,
            "profile_config_exists": False,
        }
        if not active:
            return result

        profile_config_path = os.path.join(CONFIGS_DIR, f"{active['id']}.json")
        result["profile_config_exists"] = os.path.exists(profile_config_path)
        if not result["profile_config_exists"]:
            return result

        result["attempted"] = True
        rebuild = self._rebuild_config(active["id"])
        result["success"] = rebuild.get("success", False)
        result["rebuild"] = rebuild
        return result

    # ── Plugin API: status ─────────────────────────────────────────────────────

    async def get_install_status(self) -> dict:
        state, message = self._get_install_state()
        return {
            "state":         state,
            "message":       message,
            "cli_exists":    os.path.exists(CLI_PATH),
            "config_exists": os.path.exists(CONFIG_PATH),
        }

    async def get_status(self) -> dict:
        tun_up  = self._is_tun_up()
        service = self._service_snapshot()
        running = self._service_is_active(service) or self._is_grpc_up()
        state, _ = self._get_install_state()
        active = self._get_active_profile()
        server_info = self._profile_server_info(active["id"]) if active else {}
        selected_server = server_info.get("selected", {})
        return {
            "connected":      tun_up,
            "running":        running,
            "service_active": tun_up or running,
            "vpn_ip":         self._get_vpn_ip() if tun_up else "",
            "install_state":  state,
            "active_profile": active["name"] if active else "",
            "active_server":  selected_server.get("name", "") if server_info.get("selectable") else "",
            "server_selectable": bool(server_info.get("selectable")),
        }

    # ── Plugin API: profiles ────────────────────────────────────────────────────

    async def get_profiles(self) -> list:
        return self._read_profiles()

    async def get_profile_servers(self, profile_id: str) -> dict:
        try:
            return self._profile_server_info(profile_id)
        except Exception as e:
            decky.logger.error(f"get_profile_servers: {e}")
            return {
                "profile_id": profile_id,
                "selectable": False,
                "servers": [],
                "selected": {"mode": "none", "tag": "", "name": "", "valid": False},
                "count": 0,
                "error": str(e),
            }

    async def switch_server(self, profile_id: str, mode: str, tag: str = "") -> dict:
        service = self._service_snapshot()
        grpc_up = self._is_grpc_up()
        tun_exists = self._tun_exists()
        self._debug_event(
            "switch_server.entry",
            profile_id=profile_id,
            mode=mode,
            tag=tag,
            tun_up=self._is_tun_up(),
            tun_exists=tun_exists,
            grpc_up=grpc_up,
            service=service,
        )
        if self._is_tun_up() or tun_exists or grpc_up or self._service_is_active(service):
            self._debug_event("switch_server.blocked_running", profile_id=profile_id, mode=mode, tag=tag)
            return {"success": False, "message": "Stop VPN before switching server"}

        info = self._profile_server_info(profile_id)
        if info.get("error"):
            self._debug_event("switch_server.profile_error", profile_id=profile_id, info=info)
            return {"success": False, "message": "Failed to read profile servers"}
        if not info.get("selectable"):
            return {"success": True, "message": "This profile has a single server"}

        state = self._read_server_selection_state()
        if mode == "auto":
            state[profile_id] = {"mode": "auto", "tag": ""}
            message = "Server: Hiddify default"
        elif mode == "manual":
            tags = {server["tag"] for server in info.get("servers", [])}
            if tag not in tags:
                self._debug_event("switch_server.invalid_tag", profile_id=profile_id, tag=tag, available=sorted(tags))
                return {"success": False, "message": "Selected server is not available in this profile"}
            state[profile_id] = {"mode": "manual", "tag": tag}
            server = next((item for item in info.get("servers", []) if item["tag"] == tag), None)
            message = f"Server: {server['name'] if server else tag}"
        else:
            return {"success": False, "message": "Unknown server mode"}

        write = self._write_server_selection_state(state)
        if not write.get("success"):
            self._debug_event("switch_server.write_failed", profile_id=profile_id, write=write)
            return {"success": False, "message": "Failed to save selected server"}

        rebuild = self._rebuild_config(profile_id)
        if not rebuild.get("success", False):
            self._debug_event("switch_server.rebuild_failed", profile_id=profile_id, rebuild=rebuild)
            return {"success": False, "message": "Failed to rebuild config for selected server"}

        self._debug_event(
            "switch_server.done",
            profile_id=profile_id,
            mode=mode,
            tag=tag,
            info=self._profile_server_info(profile_id),
            rebuild=rebuild,
        )
        return {"success": True, "message": message}

    async def refresh_profile(self, profile_id: str, apply_now: bool = False) -> dict:
        service = self._service_snapshot()
        grpc_up = self._is_grpc_up()
        tun_exists = self._tun_exists()
        self._debug_event(
            "refresh_profile.entry",
            profile_id=profile_id,
            apply_now=apply_now,
            profile_meta=self._profile_meta(profile_id),
            tun_up=self._is_tun_up(),
            tun_exists=tun_exists,
            grpc_up=grpc_up,
            service=service,
        )
        # Deferred apply: if the VPN is active we still download + parse the
        # subscription (download goes through tun0, which is exactly what
        # geo-blocked users need), and save it to configs/<id>.json.
        # - apply_now=False (default): keep the live current-config.json
        #   untouched; start_vpn() applies the fresh config on the next
        #   stop/start. Zero risk, zero drop.
        # - apply_now=True: rebuild current-config.json and hot-reload the
        #   running sing-box via the Clash API (PUT /configs) — tun0 stays up
        #   across the reload (verified on sing-box 1.13.1). If the Clash
        #   reload fails or tun0 drops, roll back to the previous config and
        #   reload it so the active session keeps working.
        vpn_active = self._is_tun_up() or tun_exists or grpc_up or self._service_is_active(service)
        if vpn_active:
            self._debug_event("refresh_profile.vpn_active", profile_id=profile_id, apply_now=apply_now)

        meta = self._profile_meta(profile_id)
        if not meta.get("exists"):
            return {"success": False, "message": "Profile not found"}
        if not meta.get("has_url"):
            return {"success": False, "message": "This profile has no subscription URL"}
        if not os.path.exists(CLI_PATH):
            return {"success": False, "message": "HiddifyCli is not installed"}

        url = self._profile_url(profile_id)
        parse_result = self._parse_remote_profile(profile_id, url)
        if not parse_result.get("success"):
            self._debug_event("refresh_profile.parse_failed", profile_id=profile_id, parse=parse_result)
            return {"success": False, "message": "Failed to update subscription. Open Logs for diagnostics."}

        info = self._profile_server_info(profile_id)
        selection_reset = self._reset_invalid_server_selection(profile_id, info)

        applied = False
        reload_result = {}
        rollback = {}
        # When the VPN is active, only rebuild+apply if the user asked for it
        # (apply_now); otherwise keep the live config untouched (deferred).
        if vpn_active and not apply_now:
            self._debug_event(
                "refresh_profile.rebuild_skipped_vpn_active",
                profile_id=profile_id,
                note="current-config.json untouched; start_vpn will rebuild from configs/<id>.json on next start",
            )
        elif not vpn_active or apply_now:
            # VPN off: rebuild straight into current-config.json (applied on next start).
            # VPN on + apply_now: rebuild into current-config.json then hot-reload
            # via Clash API so the running session picks up the new servers now.
            rebuild = self._rebuild_config(profile_id)
            if not rebuild.get("success", False):
                self._debug_event(
                    "refresh_profile.rebuild_failed",
                    profile_id=profile_id,
                    parse=parse_result,
                    selection_reset=selection_reset,
                    rebuild=rebuild,
                )
                return {"success": False, "message": "Updated subscription, but failed to rebuild config. Open Logs."}
            applied = True

            if vpn_active and apply_now:
                # Hot-reload the live sing-box. Back up the previous config first
                # so we can roll back if the reload drops tun0.
                ts = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
                backup_path = f"{CONFIG_PATH}.bak.{ts}"
                try:
                    import shutil
                    shutil.copy2(CONFIG_PATH, backup_path)
                except Exception as e:
                    backup_path = ""
                    self._debug_event("refresh_profile.backup_failed", profile_id=profile_id, error=str(e))
                reload_result = self._clash_reload_config(CONFIG_PATH)
                self._debug_event(
                    "refresh_profile.clash_reload",
                    profile_id=profile_id,
                    backup_path=backup_path,
                    reload=reload_result,
                )
                if not reload_result.get("success") or not reload_result.get("tun_up_after"):
                    # Reload failed or tun0 dropped — roll back to the previous
                    # working config and reload it so the live session recovers.
                    if backup_path and os.path.exists(backup_path):
                        try:
                            import shutil as _sh
                            _sh.copy2(backup_path, CONFIG_PATH)
                            rollback = self._clash_reload_config(CONFIG_PATH)
                        except Exception as e:
                            rollback = {"success": False, "error": str(e)}
                    self._debug_event("refresh_profile.rollback_after_failed_reload", profile_id=profile_id, rollback=rollback)
                    return {
                        "success": False,
                        "message": "Update downloaded, but hot-reload failed — reverted to the previous config.",
                        "applied": False,
                        "reverted": True,
                    }
                # success: tun0 still up on the new config
                applied = True

        last_update = self._update_profile_last_update(profile_id)
        refreshed_info = self._profile_server_info(profile_id)
        self._debug_event(
            "refresh_profile.done",
            profile_id=profile_id,
            profile_meta=self._profile_meta(profile_id),
            parse=parse_result,
            selection_reset=selection_reset,
            reload=reload_result,
            rollback=rollback,
            applied=applied,
            apply_now=apply_now,
            vpn_active=vpn_active,
            last_update=last_update,
            server_info=refreshed_info,
        )
        count = refreshed_info.get("count", 0)
        if applied and vpn_active and apply_now:
            message = f"Servers updated and applied: {count}"
        elif applied:
            message = f"Servers updated: {count}"
        else:
            message = f"Servers updated: {count} \u00b7 saved (applies on next VPN start)"
        return {
            "success": True,
            "message": message,
            "server_count": count,
            "selectable": bool(refreshed_info.get("selectable")),
            "applied": applied,
        }

    async def switch_profile(self, profile_id: str) -> dict:
        service = self._service_snapshot()
        grpc_up = self._is_grpc_up()
        tun_exists = self._tun_exists()
        self._debug_event(
            "switch_profile.entry",
            profile_id=profile_id,
            tun_up=self._is_tun_up(),
            tun_exists=tun_exists,
            grpc_up=grpc_up,
            service=service,
            config=self._config_summary(),
        )
        if self._is_tun_up() or tun_exists or grpc_up or self._service_is_active(service):
            self._debug_event("switch_profile.blocked_running", profile_id=profile_id)
            return {"success": False, "message": "Stop VPN before switching profile"}
        try:
            rebuild = self._rebuild_config(profile_id)
            if not rebuild.get("success", False):
                self._debug_event("switch_profile.rebuild_failed", profile_id=profile_id, rebuild=rebuild)
                return {"success": False, "message": "Failed to rebuild config"}

            db = sqlite3.connect(PROFILES_DB)
            db.execute("UPDATE profile_entries SET active = 0")
            db.execute("UPDATE profile_entries SET active = 1 WHERE id = ?", (profile_id,))
            db.commit()
            db.close()

            profiles = self._read_profiles()
            name = next((p["name"] for p in profiles if p["id"] == profile_id), profile_id)
            decky.logger.info(f"Switched to profile: {name}")
            self._debug_event(
                "switch_profile.done",
                profile_id=profile_id,
                profile_name=name,
                rebuild=rebuild,
                config=self._config_summary(),
            )
            return {"success": True, "message": f"Profile: {name}"}
        except Exception as e:
            decky.logger.error(f"switch_profile: {e}")
            self._debug_event("switch_profile.error", profile_id=profile_id, error=str(e))
            return {"success": False, "message": str(e)}

    # ── Plugin API: repair ─────────────────────────────────────────────────────

    async def repair(self) -> dict:
        try:
            self._apply_caps()
            self._ensure_tun()
            settings = self._write_hiddify_runtime_settings()
            service = self._ensure_user_service()
            self._debug_event("repair.done", settings=settings, service=service)
            return {"success": True, "message": "Permissions restored"}
        except Exception as e:
            return {"success": False, "message": str(e)}

    # ── Plugin API: VPN ────────────────────────────────────────────────────────

    @staticmethod
    def _systemctl_user(args: list) -> subprocess.CompletedProcess:
        """Run systemctl --user with proper DBUS env (works from plugin subprocess)."""
        env = os.environ.copy()
        env["DBUS_SESSION_BUS_ADDRESS"] = "unix:path=/run/user/1000/bus"
        env["XDG_RUNTIME_DIR"] = "/run/user/1000"
        return subprocess.run(
            ["systemctl", "--user"] + args,
            capture_output=True, text=True, env=env,
        )

    def _disable_user_service_autostart(self) -> dict:
        """Keep the service available for manual start, but remove boot autostart."""
        try:
            before = self._systemctl_user(["is-enabled", "hiddify"])
            disable = self._systemctl_user(["disable", "hiddify"])
            after = self._systemctl_user(["is-enabled", "hiddify"])
            after_state = (after.stdout or after.stderr).strip()
            return {
                "before": (before.stdout or before.stderr).strip(),
                "disable": _compact_process_result(disable),
                "after": after_state,
                "success": after_state != "enabled",
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def _journal_user(self, lines: int = 60) -> str:
        env = os.environ.copy()
        env["DBUS_SESSION_BUS_ADDRESS"] = "unix:path=/run/user/1000/bus"
        env["XDG_RUNTIME_DIR"] = "/run/user/1000"
        r = subprocess.run(
            ["journalctl", "--user", "-u", "hiddify", "--no-pager", "-n", str(lines)],
            capture_output=True, text=True, env=env,
        )
        return ((r.stdout or "") + (("\n" + r.stderr) if r.stderr else "")).strip()

    def _service_snapshot(self) -> dict:
        active = self._systemctl_user(["is-active", "hiddify"])
        enabled = self._systemctl_user(["is-enabled", "hiddify"])
        show = self._systemctl_user([
            "show",
            "hiddify",
            "--property=LoadState,ActiveState,SubState,Result,ExecMainStatus,ExecMainPID",
        ])
        show_map = {}
        for line in (show.stdout or "").splitlines():
            if "=" in line:
                key, value = line.split("=", 1)
                show_map[key] = value
        return {
            "active": (active.stdout or active.stderr).strip(),
            "enabled": (enabled.stdout or enabled.stderr).strip(),
            "show": show_map,
        }

    @staticmethod
    def _service_is_active(service: dict) -> bool:
        return service.get("active") in ("active", "activating")

    async def _reset_stale_runtime(self) -> dict:
        result = {
            "service_before": self._service_snapshot(),
            "grpc_up_before": self._is_grpc_up(),
            "grpc_port_before": self._grpc_port_snapshot(),
            "desktop_before": self._desktop_hiddify_snapshot(),
            "tun_exists_before": self._tun_exists(),
            "tun_up_before": self._is_tun_up(),
        }

        service = result["service_before"]
        if self._service_is_active(service):
            self._systemctl_user(["stop", "hiddify"])
            await asyncio.sleep(2)
            service = self._service_snapshot()
            result["service_after_stop"] = service
            if self._service_is_active(service):
                self._systemctl_user(["kill", "-s", "KILL", "hiddify"])
                await asyncio.sleep(1)
                self._systemctl_user(["stop", "hiddify"])
                await asyncio.sleep(2)
                service = self._service_snapshot()
                result["service_after_kill"] = service

        desktop_running = (
            result["grpc_up_before"]
            or result["desktop_before"]["pgrep_hiddify"]["rc"] == 0
            or any(unit.get("active") in ("active", "activating") for unit in result["desktop_before"].get("units", []))
        )
        if desktop_running:
            result["desktop_stop"] = await self._stop_desktop_hiddify_runtime()

        if self._is_grpc_up():
            result["grpc_port_cleanup"] = self._cleanup_grpc_port()
            await asyncio.sleep(1)

        cleanup = {}
        if self._tun_exists() or self._is_tun_up():
            cleanup = self._cleanup_tun()

        result["cleanup"] = cleanup
        result["service_after"] = self._service_snapshot()
        result["grpc_up_after"] = self._is_grpc_up()
        result["grpc_port_after"] = self._grpc_port_snapshot()
        result["desktop_after"] = self._desktop_hiddify_snapshot()
        result["tun_exists_after"] = self._tun_exists()
        result["tun_up_after"] = self._is_tun_up()
        return result

    async def start_vpn(self) -> dict:
        decky.logger.info("start_vpn called")
        self._user_stopped = False

        if self._is_tun_up():
            self._debug_event("start_vpn.already_running", tun_up=True, service=self._service_snapshot())
            return {"success": True, "message": "Already running"}

        state, _ = self._get_install_state()
        grpc_up = self._is_grpc_up()
        service = self._service_snapshot()
        self._debug_event(
            "start_vpn.entry",
            tun_up=False,
            tun_exists=self._tun_exists(),
            grpc_up=grpc_up,
            install_state=state,
            config=self._config_summary(),
            service=service,
        )
        if state != "ready":
            self._debug_event("start_vpn.not_ready", install_state=state)
            return {"success": False, "message": "Install Hiddify first"}

        if not os.path.exists(CONFIG_PATH):
            self._debug_event("start_vpn.config_missing", config=self._config_summary())
            return {"success": False, "message": "Config not found. Open Hiddify GUI and set up a profile."}

        profile_sync = self._sync_active_profile_config()
        self._debug_event(
            "start_vpn.profile_sync",
            **profile_sync,
            config=self._config_summary(),
        )
        if profile_sync.get("attempted") and not profile_sync.get("success"):
            return {"success": False, "message": "Failed to rebuild active profile config. Open Logs for diagnostics."}

        self._ensure_tun()
        if not self._check_caps():
            self._apply_caps()

        service = self._service_snapshot()
        if self._service_is_active(service) or self._tun_exists() or grpc_up:
            cleanup = await self._reset_stale_runtime()
            self._debug_event("start_vpn.pre_start_cleanup", cleanup=cleanup)
            service = self._service_snapshot()
            if self._service_is_active(service) or self._tun_exists() or self._is_grpc_up():
                self._debug_event(
                    "start_vpn.pre_start_cleanup_incomplete",
                    service=service,
                    tun_exists=self._tun_exists(),
                    grpc_up=self._is_grpc_up(),
                    port=self._grpc_port_snapshot(),
                )
                return {"success": False, "message": "Previous VPN session is stuck. Open Logs for diagnostics."}

        decky.logger.info("Managed hiddify.service inactive — starting via systemctl --user")
        self._debug_event("start_vpn.systemctl_branch", grpc_up=grpc_up, service=self._service_snapshot())

        r = self._systemctl_user(["start", "hiddify"])
        if r.returncode != 0:
            decky.logger.error(f"systemctl start failed: {r.stderr.strip()}")
            self._debug_event(
                "start_vpn.systemctl_start_failed",
                rc=r.returncode,
                stdout=(r.stdout or "").strip()[-800:],
                stderr=(r.stderr or "").strip()[-800:],
                service=self._service_snapshot(),
                journal=self._journal_user(80),
            )
            return {"success": False, "message": "Failed to start. Open Logs for diagnostics."}

        for i in range(SYSTEMD_START_TIMEOUT):
            await asyncio.sleep(1)
            if self._is_tun_up():
                decky.logger.info(f"VPN up via systemctl after {i+1}s")
                self._disable_tun_ipv6()
                self._debug_event("start_vpn.systemctl_success", elapsed=i + 1, tun_up=True, vpn_ip=self._get_vpn_ip())
                return {"success": True, "message": "VPN started"}
            status = self._systemctl_user(["is-active", "hiddify"])
            active_state = (status.stdout or status.stderr).strip()
            if (i + 1) in (5, 10, 20, SYSTEMD_START_TIMEOUT):
                self._debug_event(
                    "start_vpn.systemctl_wait",
                    elapsed=i + 1,
                    grpc_up=self._is_grpc_up(),
                    active_state=active_state,
                    service=self._service_snapshot(),
                )
            if active_state not in ("active", "activating"):
                logs = self._systemctl_user(["status", "hiddify"]).stdout[-1200:]
                decky.logger.error(f"service stopped early: {logs}")
                self._debug_event(
                    "start_vpn.systemctl_stopped_early",
                    elapsed=i + 1,
                    active_state=active_state,
                    status=logs,
                    journal=self._journal_user(80),
                    service=self._service_snapshot(),
                )
                break

        rollback = await self._reset_stale_runtime()
        self._debug_event(
            "start_vpn.systemctl_timeout",
            service=self._service_snapshot(),
            journal=self._journal_user(80),
            config=self._config_summary(),
            rollback=rollback,
        )
        return {"success": False, "message": "VPN did not start. Open Logs for diagnostics."}

    async def stop_vpn(self) -> dict:
        decky.logger.info("stop_vpn called")
        self._user_stopped = True
        service = self._service_snapshot()
        autostart = self._disable_user_service_autostart()
        self._debug_event(
            "stop_vpn.entry",
            tun_up=self._is_tun_up(),
            tun_exists=self._tun_exists(),
            grpc_up=self._is_grpc_up(),
            service=service,
            autostart=autostart,
        )
        try:
            # If the managed user service is active, stop it first.
            if self._service_is_active(service):
                self._systemctl_user(["stop", "hiddify"])
                await asyncio.sleep(2)

                service = self._service_snapshot()
                if self._service_is_active(service):
                    self._systemctl_user(["kill", "-s", "KILL", "hiddify"])
                    await asyncio.sleep(1)
                    self._systemctl_user(["stop", "hiddify"])
                    await asyncio.sleep(2)
                    service = self._service_snapshot()

            # If GUI is running without the user service — send gRPC Stop
            elif self._is_grpc_up():
                decky.logger.info("GUI gRPC detected — stopping via gRPC Core.Stop")
                self._grpc_stop()
                await asyncio.sleep(3)
                desktop_stop = {}
                if self._is_grpc_up():
                    desktop_stop = await self._stop_desktop_hiddify_runtime()
                if not self._is_tun_up() and not self._is_grpc_up():
                    decky.logger.info("VPN stopped via gRPC")
                    self._debug_event(
                        "stop_vpn.done",
                        tun_up=False,
                        tun_exists=self._tun_exists(),
                        grpc_up=False,
                        desktop_stop=desktop_stop,
                        autostart=autostart,
                        service=self._service_snapshot(),
                    )
                    return {"success": True, "message": "VPN stopped"}
                decky.logger.warning("gRPC Stop sent but tun0 still up — falling back to systemctl")

            if not self._is_tun_up():
                cleanup = {}
                if self._tun_exists():
                    cleanup = self._cleanup_tun()
                if self._is_grpc_up():
                    cleanup["desktop_runtime"] = await self._stop_desktop_hiddify_runtime()
                if self._is_grpc_up():
                    cleanup["grpc_port"] = self._cleanup_grpc_port()
                    await asyncio.sleep(1)
                service = self._service_snapshot()
                grpc_up = self._is_grpc_up()
                if self._service_is_active(service):
                    self._debug_event("stop_vpn.service_still_active", tun_up=False, tun_exists=self._tun_exists(), grpc_up=grpc_up, cleanup=cleanup, autostart=autostart, service=service)
                    return {"success": False, "message": "VPN service is still active. Open Logs for diagnostics."}
                if grpc_up:
                    self._debug_event("stop_vpn.grpc_still_active", tun_up=False, tun_exists=self._tun_exists(), grpc_up=True, cleanup=cleanup, autostart=autostart, service=service, port=self._grpc_port_snapshot())
                    return {"success": False, "message": "VPN core cleanup failed. Open Logs for diagnostics."}
                if self._tun_exists():
                    self._debug_event("stop_vpn.stale_tun_remaining", tun_up=False, tun_exists=True, grpc_up=grpc_up, cleanup=cleanup, autostart=autostart, service=service)
                    return {"success": False, "message": "VPN interface cleanup failed. Open Logs for diagnostics."}
                decky.logger.info("VPN stopped via systemctl")
                self._debug_event("stop_vpn.done", tun_up=False, tun_exists=False, grpc_up=False, cleanup=cleanup, autostart=autostart, service=service)
                return {"success": True, "message": "VPN stopped"}

            # Last resort: kill any remaining HiddifyCli processes
            subprocess.run(["pkill", "-TERM", "-f", "HiddifyC[l]i"], capture_output=True)
            await asyncio.sleep(1)
            subprocess.run(["pkill", "-KILL", "-f", "HiddifyC[l]i"], capture_output=True)
            self._systemctl_user(["stop", "hiddify"])
            await asyncio.sleep(2)
            if self._is_tun_up():
                await asyncio.sleep(2)

            cleanup = {}
            if self._is_tun_up():
                cleanup = self._cleanup_tun()

            tun_up = self._is_tun_up()
            service = self._service_snapshot()
            decky.logger.info(f"stop_vpn done, tun_up={tun_up}")
            tun_exists = self._tun_exists()
            self._debug_event("stop_vpn.done", tun_up=tun_up, tun_exists=tun_exists, cleanup=cleanup, autostart=autostart, service=service)
            if tun_up or tun_exists or self._service_is_active(service):
                return {"success": False, "message": "VPN stop incomplete. Open Logs for diagnostics."}
            return {"success": True, "message": "VPN stopped"}
        except Exception as e:
            decky.logger.error(f"stop_vpn error: {e}")
            self._debug_event("stop_vpn.error", error=str(e), autostart=autostart, service=self._service_snapshot(), journal=self._journal_user(60))
            return {"success": False, "message": str(e)}

    async def get_logs(self) -> str:
        log_path = os.path.join(decky.DECKY_PLUGIN_LOG_DIR, "hiddify.log")
        try:
            active = self._get_active_profile()
            snapshot = json.dumps({
                "plugin_version": PLUGIN_VERSION,
                "tun_up": self._is_tun_up(),
                "grpc_up": self._is_grpc_up(),
                "vpn_ip": self._get_vpn_ip(),
                "install_state": self._get_install_state()[0],
                "config": self._config_summary(),
                "hiddify_settings_path": HIDDIFY_SETTINGS_PATH,
                "hiddify_settings_exists": os.path.exists(HIDDIFY_SETTINGS_PATH),
                "active_profile": active,
                "server_info": self._profile_server_info(active["id"]) if active else {},
                "service": self._service_snapshot(),
            }, ensure_ascii=False, indent=2)
            sections = [
                ("Snapshot", snapshot),
                ("Decky Debug", self._tail_file(DEBUG_LOG_PATH, 80)),
                ("Decky Plugin Log", self._tail_file(log_path, 60)),
                ("Hiddify App Log", self._tail_file(APP_LOG_PATH, 60)),
                ("hiddify.service Journal", self._journal_user(80)),
            ]
            rendered = [
                f"== {title} ==\n{content}"
                for title, content in sections
                if content
            ]
            return "\n\n".join(rendered) if rendered else "No logs"
        except Exception as e:
            return f"Error: {e}"
        return "No logs"

    # ── Background monitor ─────────────────────────────────────────────────────

    async def _monitor_loop(self):
        prev_connected = None
        while True:
            try:
                tun_up  = self._is_tun_up()
                running = self._process_running()

                if tun_up != prev_connected:
                    decky.logger.info(f"VPN status changed: connected={tun_up} user_stopped={self._user_stopped}")
                    active = self._get_active_profile()

                    # VPN dropped unexpectedly — auto-reconnect if gRPC is still up
                    if prev_connected and not tun_up and not self._user_stopped:
                        decky.logger.info("VPN dropped (not by user) — checking if gRPC is up for auto-reconnect")
                        if self._is_grpc_up():
                            decky.logger.info("gRPC up — auto-reconnecting via Core.Start")
                            self._grpc_start()
                            await asyncio.sleep(3)
                            if self._is_tun_up():
                                decky.logger.info("Auto-reconnect succeeded")
                                self._disable_tun_ipv6()
                                prev_connected = True
                                await asyncio.sleep(5)
                                continue

                    await decky.emit("vpn_status_changed", {
                        "connected":      tun_up,
                        "running":        running,
                        "service_active": tun_up or running,
                        "vpn_ip":         self._get_vpn_ip() if tun_up else "",
                        "active_profile": active["name"] if active else "",
                        "active_server":  self._profile_server_info(active["id"]).get("selected", {}).get("name", "") if active else "",
                        "server_selectable": bool(self._profile_server_info(active["id"]).get("selectable")) if active else False,
                        "dropped":        bool(prev_connected and not tun_up and not self._user_stopped),
                    })
                    prev_connected = tun_up

                await asyncio.sleep(5)
            except asyncio.CancelledError:
                break
            except Exception as e:
                decky.logger.error(f"Monitor error: {e}")
                await asyncio.sleep(5)

    # ── Lifecycle ──────────────────────────────────────────────────────────────

    async def _main(self):
        decky.logger.info(f"Hiddify VPN plugin loaded — uid={os.getuid()}")
        os.makedirs(decky.DECKY_PLUGIN_SETTINGS_DIR, exist_ok=True)
        settings = self._write_hiddify_runtime_settings()
        service = self._ensure_user_service()
        self._debug_event(
            "plugin.load",
            uid=os.getuid(),
            install_state=self._get_install_state()[0],
            config=self._config_summary(),
            settings=settings,
            service=service,
        )

        # Re-apply sudoers + polkit on every load (survives SteamOS A/B updates)
        try:
            sudoers_path = "/etc/sudoers.d/zz-hiddify"
            with open(sudoers_path, "w") as f:
                f.write(f"deck ALL=(ALL) NOPASSWD: {CLI_PATH} *\n")
                f.write("deck ALL=(root) NOPASSWD: /usr/bin/ip link delete tun0\n")
                f.write("deck ALL=(ALL) NOPASSWD: /usr/bin/fuser *\n")
            os.chmod(sudoers_path, 0o440)
        except Exception as e:
            decky.logger.warning(f"Could not write sudoers: {e}")

        # Re-write both policy locations. /etc is the writable overlay, while
        # /usr/share is the system policy fallback when SteamOS resets /etc.
        polkit_written = False
        for polkit_dir in ("/etc/polkit-1/rules.d", "/usr/share/polkit-1/rules.d"):
            try:
                os.makedirs(polkit_dir, exist_ok=True)
                target_path = f"{polkit_dir}/10-hiddify.rules"
                tmp_path = f"{polkit_dir}/.10-hiddify.rules.tmp"
                polkit_rule = """\
polkit.addRule(function(action, subject) {
    var YES = polkit.Result.YES;
    var permission = {
        "org.freedesktop.resolve1.set-domains": YES,
        "org.freedesktop.resolve1.set-default-route": YES,
        "org.freedesktop.resolve1.set-dns-servers": YES,
        "org.freedesktop.resolve1.set-dns-over-tls": YES,
        "org.freedesktop.resolve1.set-dnssec": YES,
        "org.freedesktop.resolve1.set-dnssec-negative-trust-anchors": YES,
        "org.freedesktop.resolve1.set-llmnr": YES,
        "org.freedesktop.resolve1.set-mdns": YES,
        "org.freedesktop.resolve1.revert": YES,
        "org.freedesktop.network1.set-domains": YES,
        "org.freedesktop.network1.set-default-route": YES,
        "org.freedesktop.network1.set-dns-servers": YES,
        "org.freedesktop.network1.set-dns-over-tls": YES,
        "org.freedesktop.network1.set-dnssec": YES,
        "org.freedesktop.network1.set-dnssec-negative-trust-anchors": YES,
        "org.freedesktop.network1.set-llmnr": YES,
        "org.freedesktop.network1.set-mdns": YES,
        "org.freedesktop.network1.revert-dns": YES,
        "org.freedesktop.NetworkManager.network-control": YES,
        "org.freedesktop.NetworkManager.reload": YES,
        "org.freedesktop.NetworkManager.settings.modify.global-dns": YES,
        "org.freedesktop.NetworkManager.settings.modify.system": YES,
        "org.freedesktop.NetworkManager.wifi.share.open": YES
    };
    if (subject.user == "deck") {
        return permission[action.id];
    }
});
"""
                with open(tmp_path, "w") as f:
                    f.write(polkit_rule)
                os.chmod(tmp_path, 0o644)
                os.replace(tmp_path, target_path)
                polkit_written = True
                decky.logger.info(f"polkit rule written to {polkit_dir}")
            except Exception as e:
                decky.logger.warning(f"Could not write polkit rule to {polkit_dir}: {e}")
        if polkit_written:
            subprocess.run(["systemctl", "restart", "polkit"], check=False)

        if os.path.exists(CLI_PATH) and not self._check_caps():
            self._apply_caps()

        self._ensure_tun()
        self._monitor_task = asyncio.create_task(self._monitor_loop())

    async def _unload(self):
        decky.logger.info("Hiddify VPN plugin unloading")
        self._debug_event("plugin.unload", tun_up=self._is_tun_up(), service=self._service_snapshot())
        if self._monitor_task:
            self._monitor_task.cancel()

    async def _uninstall(self):
        await self.stop_vpn()
